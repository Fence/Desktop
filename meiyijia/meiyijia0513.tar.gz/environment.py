# coding: utf-8
import ipdb
import json
import numpy as np
import datetime as dt
from datetime import datetime as dtdt
from data_processor import DateProcessing


class Environment(object):
    """docstring for Environment"""
    def __init__(self, args):
        self.data = DateProcessing()
        self.wh_item = self.data.warehouse_item
        self.wh_data = json.load(open('data/warehouse_sales_inventory_stock_return.json','r'))
        self.wh_ind = self.item_ind = 0
        #self.stores = self.data.stores.keys()
        self.dc2num = self.data.int2onehot(self.data.dc2int)
        self.city2num = self.data.int2onehot(self.data.city2int)
        self.n_stores = args.max_stores_per_warehouse
        self.emb_dim = args.emb_dim
        self.start_date = '2017-04-01'
        self.end_date = '2018-04-22'
        self.terminal = False
        self.restart()


    def restart(self, random=False):
        while True:
            if random:
                self.wh_ind = np.random.randint(len(self.wh_item))
                self.warehouse_id = self.wh_item.keys()[self.wh_ind]
                self.item_ind = np.random.randint(len(self.wh_item[self.warehouse_id]))
                self.item_id = self.wh_item[self.warehouse_id][self.item_ind]
            else:
                self.warehouse_id = self.wh_item.keys()[self.wh_ind]
                if self.item_ind >= len(self.wh_item[self.warehouse_id]) - 1:
                    self.wh_ind = (self.wh_ind + 1) % len(self.wh_item)
                    self.warehouse_id = self.wh_item.keys()[self.wh_ind]
                    self.item_ind = 0
                else:
                    self.item_ind += 1
                self.item_id = self.wh_item[self.warehouse_id][self.item_ind]
            try:
                self.wh_item_data = json.load(open('data/items_data/%s_%s.json'%(self.warehouse_id, self.item_id),'r'))
                break
            except:
                continue
        self.cur_date = self.start_date
        self.generate_state()


    def generate_state(self):
        self.state = np.zeros([self.n_stores, self.emb_dim], dtype=np.float32)
        index = valid_count = 0
        # get warehouse-item features
        valid_days = float(self.data.items[self.item_id][-2])
        self.transp_time = self.wh_data[self.warehouse_id][self.item_id][self.cur_date]
        year, month, day = self.cur_date.split('-')
        tmp_date = list(self.data.date_transformation(year, month, day))
        promotion = [0, 0] # way, discount
        if self.item_id in self.data.promotions:
            for p in self.data.promotions[self.item_id]:
                # if this item is promoted at this day
                if p[0] <= self.cur_date <= p[1]: 
                    promotion = p[2:]
                    break
        # get store-specific features
        for store_id in self.wh_item_data:
            if self.cur_date in self.wh_item_data[store_id]:
                try:
                    x_i_j = self.wh_item_data[store_id][self.cur_date]
                    deliver_time = self.dc2num[self.data.stores[store_id][1]]
                    # no city and no weather
                    x_i_j.extend(deliver_time)
                    x_i_j.append(valid_days)
                    x_i_j.extend(self.transp_time)
                    x_i_j.extend(tmp_date)
                    x_i_j.extend(promotion)
                    #ipdb.set_trace()
                    self.state[index][:len(x_i_j)] = x_i_j
                    valid_count += 1
                except Exception as e:
                    print(e)
            index += 1
        if valid_count == 0:
            print('No record: warehouse {} item {} date {}.'.format(
                self.warehouse_id, self.item_id, self.cur_date))
        else:
            print('Has record: warehouse {} item {} date {}.\n'.format(
                self.warehouse_id, self.item_id, self.cur_date))



    def step(self, action):
        tmp_date = self.cur_date
        target_sales = target_stocks = target_returns = 0
        for d in range(self.transp_time):
            sales, _, stocks, returns = self.wh_data[self.warehouse_id][self.item_id][tmp_date][0]
            target_sales += sales
            target_stocks += stocks
            target_returns += returns
            tmp_date = self.update_date(tmp_date)

        # r = f(sales, stocks, returns, inventory)
        reward = np.square(target_sales - action)
        self.cur_date = self.update_date(self.cur_date)
        if self.cur_date > self.end_date:
            self.terminal = True
        else:
            self.terminal = False
        #self.generate_state()
        return self.state, reward, self.terminal


    def act(self):
        self.cur_date = self.update_date(self.cur_date)
        if self.cur_date > self.end_date:
            self.restart()
        self.generate_state()


    def update_date(self, cur_date):
        date = dtdt.strptime(cur_date, '%Y-%m-%d')
        new_date = date + dt.timedelta(days=1)
        return str(new_date).split()[0]


    def get_state(self):
        return self.state

    def is_terminal(self):
        return self.terminal



if __name__ == '__main__':
    ipdb.set_trace()
    env = Environment('')
    for i in xrange(400):
        env.act()