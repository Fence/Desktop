# coding: utf-8
import ipdb
import json
import numpy as np


class Environment(object):
    """docstring for Environment"""
    def __init__(self, args):
        pass


    def step(self, action):
        pass


    def act()
        